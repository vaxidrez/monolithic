﻿namespace CP.Portal.Movies.Module;

public class MovieService : IMovieService
{
    public List<MovieResponse> GetMovies()
    {
        return new List<MovieResponse>
        {
            new MovieResponse(Guid.NewGuid(), "Matrix", "Best Movie of the year"),
            new MovieResponse(Guid.NewGuid(), "Mad Max", "Futurist"),
            new MovieResponse(Guid.NewGuid(), "Kung Fu", "Asia"),
        };
    }
}
