﻿using FastEndpoints;

namespace CP.Portal.Movies.Module;

public class ListMoviesEndpoint(IMovieService movieService) 
    : EndpointWithoutRequest<ListMoviesResponse>
{
    private readonly IMovieService _movieService = movieService;

    public override void Configure()
    {
        Get("/api/movies");
        AllowAnonymous();
    }

    public override async Task HandleAsync(CancellationToken cancellationToken=default)
    {
        var movies = _movieService.GetMovies();

        var response = new ListMoviesResponse
        {
            Movies = movies
        };

        await Send.OkAsync(response);
    }


}
