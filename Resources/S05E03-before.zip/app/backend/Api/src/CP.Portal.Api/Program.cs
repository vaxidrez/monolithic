using CP.Portal.Movies.Module;
using FastEndpoints;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMovieServices();
builder.Services.AddOpenApi();
builder.Services.AddFastEndpoints();


var app = builder.Build();

app.UseFastEndpoints();

app.Run();